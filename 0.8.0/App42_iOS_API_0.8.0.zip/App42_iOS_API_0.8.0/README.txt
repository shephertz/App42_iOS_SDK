//App42 iOS SDK
1. UnZip the downloaded file
2. This will contain Shephertz_App42_iOS_API.framework ,doc, sample folder and README.txt
3. doc folder contains iOS docs
4. Sample folder contains iOS sample project for using App42 iOS SDK.
5. You need to put Shephertz_App42_iOS_API.framework in iOS Project to use this.
6. Please visit http://apps.shephertz.com/CloudAPI/cloudapidocs/index.php for detail documentaion.

Note: We are using Json framework in this SDK. If you are also want to use Json framework, don't import the framework. You can access it from App42_iOS_SDK framework like

#import "Shephertz_App42_iOS_API/JSON.h"
#import "Shephertz_App42_iOS_API/SBJSON.h"