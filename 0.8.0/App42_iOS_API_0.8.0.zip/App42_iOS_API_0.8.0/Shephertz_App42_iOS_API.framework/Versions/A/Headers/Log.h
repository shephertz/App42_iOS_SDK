//
//  Log.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Log class contain the member variables and allowed to be set and get.
 * 
 */

@interface Log : App42Response{
    
    NSMutableArray *logMessageArray;
    
}
/*!
 *set and get the logMessageArray for Log Object Which contains the LogMessage Objects.
 */
@property(nonatomic,retain) NSMutableArray *logMessageArray;

@end
