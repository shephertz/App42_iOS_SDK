//
//  Upload.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 15/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Upload class contain the member variables and allowed to be set and get.
 * 
 */


@interface Upload : App42Response{
   
}
/*!
 *set and get the fileListArray for Upload Object where fileListArray contain the File Object
 */
@property(nonatomic,retain)NSMutableArray *fileListArray;

@end
