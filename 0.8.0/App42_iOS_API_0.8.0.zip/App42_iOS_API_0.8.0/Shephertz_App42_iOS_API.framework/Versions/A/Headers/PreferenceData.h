//
//  PreferenceData.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/07/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import "App42Response.h"

@interface PreferenceData : App42Response{
    
    NSString *userId;
    NSString *itemId;
    NSString *preference;
}
/*!
 *set and get the userId for PreferenceData 
 */
@property(nonatomic,retain)NSString *userId;
/*!
 *set and get the itemId for PreferenceData 
 */
@property(nonatomic,retain)NSString *itemId;
/*!
 *set and get the preference for PreferenceData
 */
@property(nonatomic,retain)NSString *preference;


@end
