//
//  SocialResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 24/07/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "App42ResponseBuilder.h"
#import "Social.h"

@interface SocialResponseBuilder : App42ResponseBuilder

-(Social*)buildResponse:(NSString*)Json;

@end
