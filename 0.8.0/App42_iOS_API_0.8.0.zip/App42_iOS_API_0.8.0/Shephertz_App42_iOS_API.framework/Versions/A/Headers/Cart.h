//
//  Cart.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 14/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
@class Payment;

/**
 *Cart class contain the member variables and allowed to be set and get.
 * 
 */



@interface Cart : App42Response{
    
    NSString *userName;
    NSString *cartId;
    NSDate *createdOn;
    NSDate *checkOutTime;
    NSString *state;
    BOOL isEmpty;
    NSString *cartSession;
    double totalAmount;
    NSMutableArray *itemListArray;
    Payment *payemntObj;
}
/*!
 *set and get the userName for Cart Object 
 */
@property(nonatomic,retain)NSString *userName;
/*!
 *set and get the cartId for Cart Object 
 */
@property(nonatomic,retain)NSString *cartId;
/*!
 *set and get the createdOn for Cart Object 
 */
@property(nonatomic,retain)NSDate *createdOn;
/*!
 *set and get the checkOutTime for Cart Object 
 */
@property(nonatomic,retain)NSDate *checkOutTime;
/*!
 *set and get the state for Cart Object 
 */
@property(nonatomic,retain)NSString *state;
/*!
 *set and get the isEmpty for Cart Object 
 */
@property(nonatomic,assign)BOOL isEmpty;
/*!
 *set and get the cartSession for Cart Object 
 */
@property(nonatomic,retain)NSString *cartSession;
/*!
 *set and get the totalAmount for Cart Object 
 */
@property(nonatomic,assign)double totalAmount;
/*!
 *set and get the itemListArray for Cart Object Which contains the Item Objects
 */
@property(nonatomic,retain)NSMutableArray *itemListArray;
/*!
 *set and get the paymentObj for Cart Object 
 */
@property(nonatomic,retain)Payment *paymentObj;
@end
