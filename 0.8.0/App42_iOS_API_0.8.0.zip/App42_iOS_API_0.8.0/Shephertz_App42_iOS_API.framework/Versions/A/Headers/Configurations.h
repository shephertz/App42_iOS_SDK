//
//  Configurations.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 10/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Email;
/**
 *Configurations class contain the member variables and allowed to be set and get.
 * 
 */
@interface Configurations : NSObject {
    Email *emailObj;
    NSString *emailId;
    NSString *host;
    int port;
    BOOL ssl;
}
/*!
 *set and get the emailObj for Email Object 
 */
@property(nonatomic,retain)Email *emailObj;
/*!
 *set and get the emailId for Email Object 
 */
@property(nonatomic,retain)NSString *emailId;
/*!
 *set and get the host for Email Object 
 */
@property(nonatomic,retain)NSString *host;
/*!
 *set and get the port for Email Object 
 */
@property(nonatomic,assign)int port;
/*!
 *set and get the ssl for Email Object 
 */
@property(assign)BOOL ssl;
- (id) init __attribute__((unavailable));
-(id)initWithEmail:(Email *)emailObj;
//-(void)setPort:(int)port;

@end

