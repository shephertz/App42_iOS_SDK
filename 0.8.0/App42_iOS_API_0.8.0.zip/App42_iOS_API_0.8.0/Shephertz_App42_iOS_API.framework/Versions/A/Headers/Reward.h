//
//  Reward.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Reward class contain the member variables and allowed to be set and get.
 * 
 */


@interface Reward : App42Response{
    
    NSString *gameName;
    NSString *userName;
    NSString *name;
    NSString *description;
    double points;
    
}
/*!
 *set and get the gameName for Reward Object
 */
@property(nonatomic,retain)NSString *gameName;
/*!
 *set and get the userName for Reward Object
 */
@property(nonatomic,retain)NSString *userName;
/*!
 *set and get the name for Reward Object
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set and get the description for Reward Object
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the points for Reward Object
 */
@property(nonatomic,assign)double points;

@end
