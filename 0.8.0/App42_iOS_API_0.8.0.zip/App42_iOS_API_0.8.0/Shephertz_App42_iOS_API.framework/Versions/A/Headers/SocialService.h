//
//  SocialService.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 24/07/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Social.h"

@interface SocialService : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;

}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;

/**
 *  Links the User Facebook access credentials to the App User account.
 *  @param userName - Name of the user whose Facebook account to be linked
 *  @param appId - Facebook App Id
 *  @param appSecret - Facebook App Secret
 *  @param accessToken - Facebook Access Token that has been received after authorisation
 *  @returns The Social object
 */

-(Social*)linkUserFacebookAccount:(NSString *)userName appId:(NSString*)appId appSecret:(NSString*)appSecret accessToken:(NSString*)accessToken;

/**
 *  Links the User Facebook access credentials to the App User account.
 *  @param userName - Name of the user whose Facebook account to be linked
 *  @param accessToken - Facebook Access Token that has been received after authorisation
 *  @returns The Social object
 */
-(Social*)linkUserFacebookAccount:(NSString *)userName accessToken:(NSString*)accessToken;

/**
 *  Updates the Facebook status of the specified user.
 *  @param userName - Name of the user for whom the status needs to be updated
 *  @param status - status that has to be updated
 *  @returns The Facebook object
 *  
 */
-(Social *)updateFacebookStatus:(NSString *)userName status:(NSString*)status;
/**
 * Links the User Twitter access credentials to the App User account.
 * 
 * @param userName - Name of the user whose Twitter account to be linked
 * @param requestToken - Request Token retrieved from Twitter after
 *         authorizing the App
 * @param requestTokenSecret - Request Token Secret retrieved from Twitter
 *         after authorizing the App
 * @returns the Twitter object
 *  
 */
-(Social *)linkUserTwitterAccount:(NSString *)userName consumerKey:(NSString*)consumerKey consumerSecret:(NSString*)consumerSecret accessToken:(NSString*)accessToken accessTokenSecret:(NSString*)accessTokenSecret;

/**
 *  Links the User Twitter access credentials to the App User account.
 *  @param userName - Name of the user whose Twitter account to be linked
 *  @param accessToken - Twitter Access Token that has been received after authorisation
 *  @param accessTokenSecret - Twitter Access Token Secret that has been received after authorisation
 *  @returns The Social object
 *  @throws App42Exception 
 */
-(Social *)linkUserTwitterAccount:(NSString *)userName accessToken:(NSString*)accessToken accessTokenSecret:(NSString*)accessTokenSecret;
/**
 * Updates the Twitter status of the specified user.
 * 
 * @param userName - Name of the user for whom the status needs to be
 *         updated
 * @param status - status that has to be updated
 * @returns The Twitter object
 * @returns The Twitter object
 *  
 */
-(Social *)updateTwitterStatus:(NSString *)userName status:(NSString*)status;
/**
 *  Links the User LinkedIn access credentials to the App User account.
 *  @param userName - Name of the user whose LinkedIn account to be linked
 *  @param apiKey - LinkedIn App API Key
 *  @param secretKey - LinkedIn App Secret Key
 *  @param accessToken - LinkedIn Access Token that has been received after authorisation
 *  @param accessTokenSecret - LinkedIn Access Token Secret that has been received after authorisation
 *  @returns The Social object
 */
-(Social *)linkUserLinkedInAccount:(NSString *)userName apiKey:(NSString*)linkedInApiKey secretKey:(NSString*)linkedInSecretKey accessToken:(NSString*)accessToken accessTokenSecret:(NSString*)accessTokenSecret;

/**
 *  Links the User LinkedIn access credentials to the App User account.
 *  @param userName - Name of the user whose LinkedIn account to be linked
 *  @param accessToken - LinkedIn Access Token that has been received after authorisation
 *  @param accessTokenSecret - LinkedIn Access Token Secret that has been received after authorisation
 *  @returns The Social object
 */
-(Social *)linkUserLinkedInAccount:(NSString *)userName accessToken:(NSString*)accessToken accessTokenSecret:(NSString*)accessTokenSecret;

/**
 * Updates the LinkedIn status of the specified user.
 * 
 * @param userName - Name of the user for whom the status needs to be updated
 * @param status - status that has to be updated
 * @returns The Social object
 */
-(Social *)updateLinkedInStatus:(NSString *)userName status:(NSString*)status;
/**
 * Updates the status for all linked social accounts of the specified user.
 * 
 * @param userName - Name of the user for whom the status needs to be updated
 * @param status - status that has to be updated
 * @returns The Social object
 */
-(Social *)updateSocialStatusForAll:(NSString *)userName status:(NSString*)status;

@end
