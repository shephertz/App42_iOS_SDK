//
//  LogResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42ResponseBuilder.h"
#import "Log.h"

@interface LogResponseBuilder : App42ResponseBuilder

-(Log*)buildLogResponse:(NSString*)Json;


@end
