//
//  RecommendedItem.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 12/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Recommender;

/**
 *RecommendedItem class contain the member variables and allowed to be set and get.
 * 
 */
@interface RecommendedItem : NSObject{
    NSString *userId;
    NSString *item;
    double value;
    Recommender *recommenderObject;
}
/*!
 *set and get the userId for RecommendedItem Object 
 */
@property(nonatomic,retain)NSString *userId;
/*!
 *set and get the item for RecommendedItem Object 
 */
@property(nonatomic,retain)NSString *item;
/*!
 *set and get the value for RecommendedItem Object 
 */
@property(nonatomic,assign)double value;
/*!
 *set and get the recommenderObject for RecommendedItem Object 
 */
@property(nonatomic,retain)Recommender *recommenderObject;


- (id) init __attribute__((unavailable));

-(id)initWithRecommender:(Recommender*)recommenderObj;

@end
