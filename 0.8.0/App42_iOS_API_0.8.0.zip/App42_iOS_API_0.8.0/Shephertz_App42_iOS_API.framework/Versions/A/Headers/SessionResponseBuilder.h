//
//  SessionResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 05/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42ResponseBuilder.h"
#import "Session.h"

@interface SessionResponseBuilder : App42ResponseBuilder

-(Session*)buildSessionResponse:(NSString*)Json;

@end
