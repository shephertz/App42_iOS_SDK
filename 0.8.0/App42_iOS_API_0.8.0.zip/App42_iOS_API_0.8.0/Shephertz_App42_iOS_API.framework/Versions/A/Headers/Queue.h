//
//  Queue.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Queue class contain the member variables and allowed to be set and get .
 * 
 */


@interface Queue :App42Response{
    NSString *queueType;
    NSString *queueName;
    NSString *description;
    NSMutableArray *messageArray;
}
/*!
 *set and get the queueType for Queue Object 
 */
@property(nonatomic,retain)NSString *queueType;
/*!
 *set and get the queueName for Queue Object 
 */
@property(nonatomic,retain)NSString *queueName;
/*!
 *set and get the description for Queue Object 
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the messageArray for Queue Object Which contains the Message Objects
 */
@property(nonatomic,retain)NSMutableArray *messageArray;

-(id)init;

@end
