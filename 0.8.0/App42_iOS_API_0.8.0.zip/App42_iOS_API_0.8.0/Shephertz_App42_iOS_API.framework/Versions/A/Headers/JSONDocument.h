//
//  JSONDocument.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 13/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Storage;

/**
 *JSONDocument class contain the member variables and allowed to be set and get.
 * 
 */


@interface JSONDocument : NSObject{
    NSString *jsonDoc;
    NSString *docId;
    Storage *storageObject;
    
}
/*!
 *set and get the jsonDoc for JSONDocument Object
 */
@property(nonatomic,retain)NSString *jsonDoc;
/*!
 *set and get the docId for JSONDocument Object
 */
@property(nonatomic,retain)NSString *docId;
/*!
 *set and get the storageObject for JSONDocument Object
 */
@property(nonatomic,retain)Storage *storageObject;

- (id) init __attribute__((unavailable));

-(id)initWithStorage:(Storage*)storageObj;

@end
