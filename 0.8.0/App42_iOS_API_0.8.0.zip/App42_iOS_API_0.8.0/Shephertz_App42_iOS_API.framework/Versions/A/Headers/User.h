//
//  User.h
//  App42_iOS_SERVICE_API
//
//  Created by Shephertz Technology on 07/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
@class Profile;

/**
 *User class contain the member variables and allowed to be set and get.
 * 
 */


@interface User : App42Response{
    NSString *userName;
    NSString *email;
    NSString *password;
    NSArray *roleList;
    Profile *profile;
}
/*!
 *set and get the userName for User Object 
 */
@property(nonatomic,retain)NSString *userName;
/*!
 *set and get the email for User Object 
 */
@property(nonatomic,retain)NSString *email;
/*!
 *set and get the password for User Object 
 */
@property(nonatomic,retain)NSString *password;
/*!
 *set and get the profile Object for User Object 
 */
@property(nonatomic,retain)Profile *profile;
/*!
 *set and get the profile Object for User Object 
 */
@property(nonatomic,retain)NSArray *roleList;

-(NSString*)toString;
@end
