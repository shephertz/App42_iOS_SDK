//
//  File.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 13/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
@class Upload;

/**
 *File class contain the member variables for File Object
 * 
 */

@interface File : App42Response{
    
}
/*!
 *set and get the name for File Object 
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set and get the userName for File Object 
 */
@property(nonatomic,retain)NSString *userName;
/*!
 *set and get the type for File Object 
 */
@property(nonatomic,retain)NSString *type;
/*!
 *set and get the url for File Object 
 */
@property(nonatomic,retain)NSString *url;
/*!
 *set and get the url for File Object 
 */
@property(nonatomic,retain)NSString *tinyUrl;
/*!
 *set and get the description for File Object 
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the uploadObject for File Object 
 */
@property(nonatomic,retain)Upload *uploadObject;

- (id) init __attribute__((unavailable));

-(id)initWithUpload:(Upload*)uploadObj;

@end
