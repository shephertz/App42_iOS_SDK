//
//  UserService.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 09/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//




#import <Foundation/Foundation.h>
#import "Profile.h"
#import "UserResponseBuilder.h"
@class User;
@class App42Response;

extern NSString *const MALE;
extern NSString *const FEMALE;

/**
 * Creates User for the App. App42 Cloud API's provides a complete User
 * Management for any Mobile or Web App. It supports User registration,
 * retrieval, state management e.g. lock, delete and Authentication.
 * 
 * Along with User Management the platform provides API's for persistent
 * SessionManagement
 * 
 * @see SessionService
 * @see User
 * @see App42Response
 */


@interface UserService : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
}
@property(nonatomic,retain)NSString *apiKey;
@property(nonatomic,retain)NSString *secretKey;
/**
 * Create User for the App
 * 
 * @param uName UserName which should be unique for the App
 * @param pwd Password for the User
 * @param emailAddress Email address of the user
 * @return The created User Object.
 */
-(User*)createUser:(NSString*)uName password:(NSString*)pwd emailAddress:(NSString*)emailAddress;
/**
 * Create User for the App
 * 
 * @param uName
 *            UserName which should be unique for the App
 * @param pwd
 *            Password for the User
 * @param emailAddress
 *            Email address of the user
 * @param roleList
 *            list of roles to be assigned to User
 * @return The created User Object.
 */
-(User*)createUser:(NSString*)uName password:(NSString*)pwd emailAddress:(NSString*)emailAddress roleList:(NSArray*)roleList;
/**
 * Add Role for the App
 * 
 * @param uName
 *            UserName which should be unique for the App
 * @param roleList
 *            list of roles to be assigned to User
 * @return The created User Object.
 */
-(User*)assignRoles:(NSString*)uName roleList:(NSArray*)roleList;
/**
 * Gets user details based on userName
 * 
 * @param userName UserName which should be unique for the App
 * @return Returns User Object
 */
-(User*)getUser:(NSString*)userName;
/**
 * Get Roles based on userName
 * 
 * @param userName
 *            UserName which should be unique for the App
 * @return Returns User Object
 */
-(User*)getRolesByUser:(NSString*)userName;
/**
 * Get Users based on Role
 * 
 * @param role
 *            Role which should be unique for the App
 * @return Returns User Object
 */
-(NSArray*)getUsersByRole:(NSString*)role;
/**
 * Gets the count of all the users 
 * 
 * @return Returns the count of all User exists
 */
-(App42Response*)getAllUsersCount;
/**
 * Gets the count of all the locked users 
 * 
 * @return Returns the count of locked User exists
 */
-(App42Response*)getLockedUsersCount;
/**
 * Gets All users details
 * 
 * @return Returns the list that contains all User Object
 */
-(NSArray*)getAllUsers;
/**
 * Gets All users By Paging
 * 
 * @param max
 *            Maximum number of records to be fetched
 * @param offset
 *            From where the records are to be fetched
 * @return Returns the list that contains all User Object
 */

-(NSArray*)getAllUsers:(int)max offset:(int)offset;
/**
 * Gets All the locked users details
 * 
 * @return Returns the list that contains locked User Objects
 */
-(NSArray*)getLockedUsers;

/**
 * Gets All the locked users  details By paging.
 * 
 * @param max
 *            Maximum number of records to be fetched
 * @param offset
 *            From where the records are to be fetched
 * @return Returns the list that contains locked User Objects
 */
-(NSArray*)getLockedUsers:(int)max offset:(int)offset;

/**
 * Gets user details based on emailId
 * 
 * @param emailId EmailId of the user to be retrieved
 * @return Returns User Object
 */
-(User*)getUserByEmailId:(NSString*)emailId;
/**
 *  Gets user details based on userName
 *  @param userName UserName which should be unique for the App
 *  @return Returns True or False based on User lock status 
 */
-(User*)isUserLocked:(NSString*)userName;
/**
 * Updates the User based on userName. Note: Only email can be updated.
 * Username cannot be updated.
 * 
 * @param uName UserName which should be unique for the App
 * @param emailAddress Email address of the user
 * @returns updated User Object
 */
-(User*)updateEmail:(NSString*)uName emailAddress:(NSString*)emailAddress;
/**
 * Deletes a particular user based on userName.
 * 
 * @param userName UserName which should be unique for the App
 * @returns App42Response Object if user deleted successfully
 */
-(App42Response*)deleteUser:(NSString*)userName;
/**
 * Creates or Updates User Profile. First time the Profile for the user is
 * created and in future calls user profile will be updated. This will
 * always update the profile with new value passed in profile object. Call
 * to this method should have all the values you want to retain in user
 * profile object, otherwise old values of profile will get updated with
 * null.
 * Method only updates the profile of user, passing email/password in user 
 * object does not have any significance for this method call.
 * 
 * @param user - User for which profile has to be updated, this should
 *         contain the userName and profile object in it. 
 * @returns User Object with updated Profile information
 *  @see ProfileData
 */
-(User*)createOrUpdateProfile:(User *)user;
/**
 * Authenticate user based on userName and password
 * 
 * @param uName UserName which should be unique for the App
 * @param pwd Password for the User
 * @returns App42Response Object if authenticated successfully.
 */
-(App42Response*)authenticateUser:(NSString*)uName password:(NSString*)password;
/**
 * Locks the user based on the userName. Apps can use these feature to lock
 * a user because of reasons specific to their usercase e.g. If payment not
 * received and the App wants the user to be inactive
 * 
 * @param uName UserName which should be unique for the App
 * @returns Returns the locked User Object
 */
-(User*)lockUser:(NSString*)uName;
/**
 * Unlock the user based on the userName. Apps can use these feature to
 * unlock a user because of reasons specific to their usercase e.g. If
 * payment received and the App wants to the user to be active.
 * 
 * @param uName UserName which should be unique for the App
 * @returns Returns the unlocked User Object
 */
-(User*)unlockUser:(NSString*)uName;
/**
 * Change the password for user based on the userName.
 * 
 * @param uName UserName which should be unique for the App
 * @param oldPwd Old Password for the user for authentication
 * @param newPwd New Password for the user to change
 * @returns App42Response Object if updated successfully
 */
-(App42Response*)changeUserPassword:(NSString*)uName oldPassword:(NSString*)oldPwd newPassword:(NSString*)newPwd;
/**
 * Revokes the specified role from the user.
 * 
 * @param userName
 *            UserName which should be unique for the App
 * @returns App42Response Object if user deleted successfully
 */
-(App42Response*)revokeRole:(NSString*)userName role:(NSString*)role;
/**
 * Revokes the specified role from the user.
 * 
 * @param userName
 *            UserName which should be unique for the App
 * @returns App42Response Object if user deleted successfully
 */
-(App42Response*)revokeAllRoles:(NSString*)userName;
/**
 * Get Users based on Profile Data
 * 
 * @param profileData
 *            Profile Data key/value for which Users need to be retrieved
 * @return ArrayList of User Object for that particular role
 */
-(NSArray*)getUsersByProfileData:(Profile*)profileData;
/**
 * Updates the User based on userName. Note: Only email can be updated.
 * Username cannot be updated.
 * 
 * @param uName
 *            UserName which should be unique for the App
 * @param emailAddress
 *            Email address of the user
 * @returns updated User Object
 */
-(User*)resetUserPassword:(NSString*)uName pwd:(NSString*)pwd;
@end
