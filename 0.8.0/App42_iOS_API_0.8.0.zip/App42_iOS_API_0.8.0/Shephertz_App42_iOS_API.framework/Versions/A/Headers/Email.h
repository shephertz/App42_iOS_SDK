//
//  Email.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 10/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Email class contain the member variables and allowed to be set and get.
 * 
 */


@interface Email : App42Response{
    
    NSString *from;
    NSString *to;
    NSString *subject;
    NSString *body;
    NSMutableArray *configurationArray;
    
}
/*!
 *set and get the from for Email Object 
 */
@property(nonatomic,retain)NSString *from;
/*!
 *set and get the to for Email Object 
 */
@property(nonatomic,retain)NSString *to;
/*!
 *set and get the subject for Email Object 
 */
@property(nonatomic,retain)NSString *subject;
/*!
 *set and get the body for Email Object 
 */
@property(nonatomic,retain)NSString *body;
/*!
 *set and get the configurationArray for Email Object which contains configuration Objects.
 */
@property(nonatomic,retain)NSMutableArray *configurationArray;
-(id)init;

@end
