//
//  CartResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 13/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42ResponseBuilder.h"
@class Cart;

@interface CartResponseBuilder : App42ResponseBuilder

-(Cart*)buildResponse:(NSString*)Json;
-(NSArray *)buildArrayResponse:(NSString*)Json;

@end
