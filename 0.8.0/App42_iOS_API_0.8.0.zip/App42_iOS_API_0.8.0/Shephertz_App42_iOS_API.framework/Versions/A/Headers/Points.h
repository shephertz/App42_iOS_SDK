//
//  Points.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 12/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
#import "Geo.h"

/**
 *Points class contain the member variables and allowed to be set and get.
 * 
 */

@interface Points : App42Response{
    double lat;
    double lng;
    NSString *marker;
    Geo *geoObject;
}
/*!
 *set and get the lat for Points Object
 */
@property(nonatomic,assign)double lat;
/*!
 *set and get the lng for Points Object
 */
@property(nonatomic,assign)double lng;
/*!
 *set and get the marker for Points Object
 */
@property(nonatomic,retain)NSString *marker;
/*!
 *set and get the geoObject Ref for Points Object
 */
@property(nonatomic,retain)Geo *geoObject;

- (id) init __attribute__((unavailable));

-(id)initWithGeo:(Geo*)geoObj;
@end
