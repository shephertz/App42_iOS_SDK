//
//  Score.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
@class Game;

/**
 *Score class contain the member variables and allowed to be set and get.
 * 
 */


@interface Score : App42Response{
    
    NSString *userName;
    NSString *rank;
    NSDate *createdOn;
    double value;
    Game *gameObject;
    
}
/*!
 *set and get the userName for Score Object
 */
@property(nonatomic,retain)NSString *userName;
/*!
 *set and get the rank for Score Object
 */
@property(nonatomic,retain)NSString *rank;
/*!
 *set and get the createdOn for Score Object
 */
@property(nonatomic,retain)NSDate *createdOn;
/*!
 *set and get the value for Score Object
 */
@property(nonatomic,assign)double value;
/*!
 *set and get the gameObject for Score 
 */
@property(nonatomic,retain)Game *gameObject;

- (id) init __attribute__((unavailable));

-(id)initWithGame:(Game*)gameObj;

@end
