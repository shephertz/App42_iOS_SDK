//
//  TestClassAppDelegate.h
//  SampleApp
//
//  Created by Shephertz Technology on 14/05/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Shephertz_App42_iOS_API/Shephertz_App42_iOS_API.h"

@interface TestClassAppDelegate : UIResponder <UIApplicationDelegate>{
    ServiceAPI *serviceAPIObject;
}

@property (strong, nonatomic) UIWindow *window;

@end
