//
//  main.m
//  SampleApp
//
//  Created by Shephertz Technology on 14/05/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TestClassAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TestClassAppDelegate class]));
    }
}
