//
//  SampleAppTests.m
//  SampleAppTests
//
//  Created by Shephertz Technology on 14/05/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import "SampleAppTests.h"

@implementation SampleAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SampleAppTests");
}

@end
