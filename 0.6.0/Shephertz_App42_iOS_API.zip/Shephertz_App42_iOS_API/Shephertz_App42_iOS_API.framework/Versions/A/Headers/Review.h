//
//  Review.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 15/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * The service is a Review & Rating manager for any item. The item can be anything which has an id
 * e.g. App on a AppStore/Marketplace, items in a catalogue, articles, blogs etc.
 * It manages the comments and its associated rating. It also provides methods to fetch average, highest etc. Reviews.
 * Reviews can be also be muted or unmuted if it has any objectionable content.
 * 
 */


@interface Review : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 * Creates review for the specified item on the cloud
 * @param userId The user who has created the review
 * @param itemId The item for which the review has to be created
 * @param reviewComment The review comment
 * @param reviewRating Review rating in double
 * @return Returns the review which has been created
 */
-(NSString*)createReview:(NSString*)userId itemID:(NSString*)itemId reviewComment:(NSString*)reviewComment reviewRating:(double)reviewRating;
/**
 * Fetches all reviews for the App
 * @return Returns all the reviews for the App
 */
-(NSString*)getAllReviews;
/**
 * Fetches the average review for the specified itemId
 * @param itemId The item for which the average review has to be fetched
 * @return Returns the average review for a item
 */
-(NSString*)getAverageReviewByItem:(NSString*)itemId;
/**
 * Fetches All Reviews based on the itemId
 * @param itemId The item for which reviews have to be fetched
 * @return Returns all the reviews for a item
 */
-(NSString*)getReviewByItem:(NSString*)itemId;
/**
 * Fetches the highest review for the specified itemId
 * @param itemId The item for which the highest review has to be fetched
 * @return Returns the highest review for a item
 */
-(NSString*)getHighestReviewByItem:(NSString*)itemId;
/**
 * Fetches the lowest review for the specified itemId
 * @param itemId The item for which the lowest review has to be fetched
 * @return Returns the lowest review for a item
 */
-(NSString*)getLowestReviewByItem:(NSString*)itemId;
/**
 * Mutes a review
 * @param reviewId The review which has to be muted
 * @return Returns the muted Review
 */
-(NSString*)mute:(NSString*)reviewId;
/**
 * UnMutes a review
 * @param reviewId The review which has to be unmuted
 * @return Returns the unmuted Review
 */
-(NSString*)unmute:(NSString*)reviewId;

@end
