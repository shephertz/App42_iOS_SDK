//
//  Queue.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 11/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Manages Asynchronous queues. Allows to create, delete, purge messages, view pending messages and
 * get all messages
 * 
 */
@interface Queue : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 *  Creates a type Pull Queue
 *  @param queueName The name of the queue which has to be created
 *  @param queueDescription The description of the queue
 *  @return Queue name which has been created 
 */
-(NSString*)createPullQueue:(NSString*)queueName description:(NSString*)queueDescription;
/**
 *  Deletes the Pull type Queue
 *  @param queueName The name of the queue which has to be deleted
 *  @return Queue name which has been deleted 
 */
-(NSString*)deletePullQueue:(NSString*)queueName;
/**
 *  Purges message on the Queue. Note: once the Queue is purged the messages
 *  are removed from the Queue and wont be available for dequeueing.
 *  @param queueName The name of the queue which has to be purged
 *  @return Queue name which has been purged 
 */
-(NSString*)purgePullQueue:(NSString*)queueName;
/**
 *  Messages which are pending to be dequeue. Note: Calling this method does not
 *  dequeue the messages in the Queue. The messages stay in the Queue till they are dequeued
 *  @param queueName The name of the queue from which pending messages have to be fetchd
 *  @return Pending messages in the Queue
 */
-(NSString*)pendingMessages:(NSString*)queueName;

/**
 *  Messages are retrieved and dequeued from the Queue. 
 *  @param queueName The name of the queue which have to be retrieved
 *  @param receiveTimeOut Receive time out
 *  @return Gets messages in the Queue
 */

-(NSString*)getMessages:(NSString*)queueName receiveTimeOut:(long)receiveTimeOut;


@end
