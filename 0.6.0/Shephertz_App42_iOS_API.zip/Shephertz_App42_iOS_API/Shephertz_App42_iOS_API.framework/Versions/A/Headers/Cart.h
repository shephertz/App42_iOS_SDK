//
//  Cart.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 14/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * This is Cloud Persistent Shopping Cart Service. App Developers can use this to 
 * create a Shopping Cart. Add Items and Check Out items. It also maintains the transactions
 * and the corresponding Payment Status.
 * The Payment Gateway interface is not provided by the Platform. It is left to the App developer
 * how he wants to do the Payment Integration. This can be used along with Catalogue or used independently
 * 
 * @see Catalgoue
 * 
 */



typedef enum TransactionStatus {
    DECLINED,AUTHORIZED,PENDING
} transactionStatus;


@interface Cart : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 * Creates a Cart Session for the specified User
 * @param user User for whom Cart Session has to be created
 * returns The Cart Id with Creation Time. The id has to be used in subsequent calls for 
 *         adding and checking out
 */
-(NSString*)createCart:(NSString*)user;
/**
 * Fetch Cart details. Can be used by the App developer to display Cart Details i.e. Items in a Cart.
 * @param cartId The Cart Id that has to be fetched
 * @returns Cart details with all the items which are in it. It also tells the state of the Cart
 */
-(NSString*)getCartDetails:(NSString*)cartId;
/**
 * Adds an Item in the Cart with quantity and price. This method does not take currency. Its the
 * onus of the App developer to maitain the currency. It takes only the price.
 * @param cartID The Cart Id into which item has to be added
 * @param itemID The Item id which has to be added in the cart. If the Catalogue Service is used along
 *         with the Cart Service then the Item ids should be same.
 * @param itemQuantity Quantity of the Item to be purchased
 * @param price Price of the item
 * @returns the added item
 */
-(NSString*)addItem:(NSString*)cartID itemID:(NSString*)itemID itemQuantity:(int)itemQuantity price:(double)price;
/**
 * Fetches the Items from the specified Cart
 * @param cartId The cart id from which items have to be fetched
 * @returns All Items in the Cart
 */
-(NSString*)getItems:(NSString*)cartId;
/**
 * Fetches the specified Item from the specified Cart
 * @param cartId The cart id from which item has to be fetched
 * @param itemId The item for which the information has to be fetched
 * @returns Item information whose id has been provided
 */
-(NSString*)getItem:(NSString*)cartId itemId:(NSString*)itemId;
/**
 * Removes the specified item from the specified Cart
 * @param cartId The cart id from which the item has to be removed
 * @param itemId Id of the Item which has to be removed
 * @returns Removed Item information
 */
-(NSString*)removeItem:(NSString*)cartId itemId:(NSString*)itemId;
/**
 * Removes all Items from the specified Cart
 * @param cartId The cart id from which items have to be removed
 * @returns Removed Items information
 */
-(NSString*)removeAllItems:(NSString*)cartId;
/**
 * Checks whether the Cart is Empty or not
 * @param cartId The cart id to check for empty
 * @returns Whether Cart is empty or not
 */
-(NSString*)isEmpty:(NSString*)cartId;
/**
 * Checks out the Cart and put it in CheckOut Stage and returns the Transaction Id
 * The transaction id has to be used in future to update the Payment Status.
 * @param cartID The cart id that has to be checkedout
 * @returns Checked Out Cart Information with the Transaction Id 
 */
-(NSString*)checkOut:(NSString*)cartID;
/**
 * Update Payment Status of the Cart. When a Cart is checkout, it is in Checkout state. The payment
 * status has to be updated based on the Payment Gateway interaction
 * @param cartID The cart id for which the payment status has to be updated
 * @param transactionID Transaction id for which the payment status has to be updated
 * @param paymentStatus Payment Status to be updated.  Use the defined constants for them AUTHORIZED, DECLINED, PENDING.
 * @returns Payment Status
 */
-(NSString*)payment:(NSString*)cartID transactionID:(NSString*)transactionID paymentStatus:(transactionStatus)paymentStatus;

/**
 * Fetches Payment information for a User. This can be used to display Order and Payment History
 * @param userId User Id for whom payment information has to be fetched
 * @returns Payment History for the user
 */
-(NSString*)getPaymentsByUser:(NSString*)userId;
/**
 * Fetches Payment information for the specified Cart Id
 * @param cartID Cart Id for which the payment information has to be fetched
 * @returns Payment History for the specified Cart
 */
-(NSString*)getPaymentsByCart:(NSString*)cartID;

/**
 * Fetches Payment information based on User Id and Status
 * @param userId User Id for whom payment information has to be fetched
 * @param paymentStatus Status of type which payment information has to be fetched. Use the defined constants for them AUTHORIZED, DECLINED, PENDING
 * @returns Payment History
 */
-(NSString*)getPaymentsByUserAndStatus:(NSString*)userId status:(transactionStatus)paymentStatus;

/**
 * Fetches Payment information based on Status
 * @param paymentStatus Status of type which payment information has to be fetched. Use the defined constants for them AUTHORIZED, DECLINED, PENDING
 * @returns Payment History
 */
-(NSString*)getPaymentsByStatus:(transactionStatus)paymentStatus;
/**
 * History of Carts and Payments for a User. It gives all the carts which are in AUTHORIZED, DECLINED, PENDING state.
 * @param userId User Id for whom payment history has to be fetched
 * @returns Payment History for the specified user
 */
-(NSString*)getPaymentHistoryByUser:(NSString*)userId;

/**
 * History of all carts. It gives all the carts which are in AUTHORIZED, DECLINED, PENDING state.
 * @returns Payment History for all.
 */
-(NSString*)getPaymentHistoryAll;
@end
