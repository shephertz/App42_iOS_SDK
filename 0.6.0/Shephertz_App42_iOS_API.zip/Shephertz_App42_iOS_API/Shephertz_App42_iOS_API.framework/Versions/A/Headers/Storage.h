//
//  Storage.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 15/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Storage service on cloud provides the way to store the JSON document in NoSQL database running on cloud.
 * One can store the JSON document, update it , serach it and can apply the map-reduce search on stored documents.
 * Example : If one will store JSON doc {"date":"5Feb"} it will be stored with unique Object Id and stored JSON object will loook like
 * { "date" : "5Feb" , "_id" : { "$oid" : "4f423dcce1603b3f0bd560cf"}}. This oid can further be used to access/search the document.
 * 
 * 
 */
@interface Storage : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 * Save the JSON document in given database name and collection name.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc has to be saved.
 * @param json Target JSON document to be saved
 * @return Returns the saved document containing Object Id as a unique handler of saved document.
 * 
 */
-(NSString*)insertJSONDocument:(NSString*)dbName collectionName:(NSString*)collectionName json:(NSString*)json;
/**
 * Find all documents stored in given database and collection.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc needs to be searched.
 * @return Returns the set of JSON document.
 * 
 */
-(NSString*)findAllDocumnets:(NSString*)dbName collectionName:(NSString*)collectionName;
/**
 * Find target document by given unique object id.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc needs to be searched.
 * @param docId  Unique Object Id handler.
 * @return Returns the target of JSON document.
 * 
 */
-(NSString*)findDocumentById:(NSString*)dbName collectionName:(NSString*)collectionName docId:(NSString*)docId;
/**
 * Find target document using key value serach parameter. 
 * This key value pair will be searched in the JSON doc stored on the cloud and matching Doc will be returned as a result of this method.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc needs to be searched.
 * @param key Key to be searched for target JSON doc.
 * @param value Value to be searched for target JSON doc.
 * @return Returns the set of JSON document.
 * 
 */
-(NSString*)findDocumentByKeyValue:(NSString*)dbName collectionName:(NSString*)collectionName key:(NSString*)key value:(NSString*)value;
/**
 * Update target document using key value serach parameter. 
 * This key value pair will be searched in the JSON doc stored in the cloud and matching Doc will be updated with new value passed.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc needs to be searched.
 * @param key Key to be searched for target JSON doc.
 * @param value Value to be searched for  target JSON doc.
 * @param newJsonDoc New Json document to be added.
 * @return Returns the updated of JSON document.
 * 
 */
-(NSString*)updateDocumentByKeyValue:(NSString*)dbName collectionName:(NSString*)collectionName key:(NSString*)key value:(NSString*)value newJsonDoc:(NSString*)newJsonDoc;
/**
 * Delete target document using Object Id from given db and collection. 
 * The Object Id will be searched in the JSON doc stored on the cloud and matching Doc will be deleted.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc needs to be searched.
 * @param docId  Unique Object Id handler.
 * @return Returns the deleted JSON document.
 * 
 */
-(NSString*)deleteDocumentById:(NSString*)dbName collectionName:(NSString*)collectionName docId:(NSString*)docId;

/**
 * Save the JSON document in given database name and collection name. It accepts the HashMap containing key-value and convert it into JSON.
 * Converted JSON doc further saved on the cloud using given db name and collection name.
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc has to be saved.
 * @param map HashMap containing key-value pairs
 * @return Returns the inserted JSON document.
 * 
 */
-(NSString*)insertJsonDocUsingMap:(NSString*)dbName collectionName:(NSString*)collectionName map:(NSMutableDictionary*)map;
/**
 * Map reduce function to search the target document.
 * Please see detail information on map-reduce http://en.wikipedia.org/wiki/MapReduce 
 * @param dbName Unique handler for storage name
 * @param collectionName Name of collection under which JSON doc needs to be searched.
 * @param mapFunction Map function to be used to search the document
 * @param reduceFunction Reduce function to be used to search the document
 * @return Returns the target  JSON document.
 * 
 */
-(NSString*)mapReduce:(NSString*)dbName collectionName:(NSString*)collectionName mapFunction:(NSString*)mapFunction reduceFunction:(NSString*)reduceFunction;


@end
