//
//  GeoPoint.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 17/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GeoPoint : NSObject{
    double latitude;
    double longitude;
    NSString *marker;
}
@property(nonatomic)double latitude;
@property(nonatomic)double longitude;
@property(nonatomic,retain)NSString *marker;
-(NSMutableDictionary*)getGeoPointValues;

@end
