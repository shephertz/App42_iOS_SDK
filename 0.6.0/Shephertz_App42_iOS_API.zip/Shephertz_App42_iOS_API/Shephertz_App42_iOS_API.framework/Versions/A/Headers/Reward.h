//
//  Reward.h
//  App42_iOS_SERVICE_APIs
//
//  Created by Shephertz Technology on 21/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Define a Reward e.g. Sword, Energy etc. Is needed for Reward Points
 * 
 * The Game service allows Game, User, Score and ScoreBoard Management on the Cloud.
 * The service allows Game Developer to create a Game and then do in Game Scoring using the
 * Score service. It also allows to maintain a Scoreboard across game sessions using the ScoreBoard
 * service. One can query for average or highest score for user for a Game and highest and average score across users
 * for a Game. It also gives ranking of the user against other users for a particular game.
 * The Reward and RewardPoints allows the Game Developer to assign rewards to a user and redeem the rewards.
 * E.g. One can give Swords or Energy etc.
 * The services Game, Score, ScoreBoard, Reward, RewardPoints can be used in Conjunction for complete Game Scoring and Reward
 * Management.
 * 
 * @see Game, RewardPoint, Score, ScoreBoard
 */
@interface Reward : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 * Creates Reward. Reward can be Sword, Energy etc. When Reward Points have to be 
 * added the Reward name created using this method has to be specified.
 * @param rewardName - The reward that has to be created
 * @param rewardDescription - The description of the reward to be created
 * @return Returns the reward that has been created
 */
-(NSString*)createReward:(NSString*)rewardName rewardDescription:(NSString*)rewardDescription;
/**
 * Fetches all the Rewards
 * @return Returns all the rewards of the App
 */
-(NSString*)getAllRewards;
/**
 * Retrieves the reward for the specified name
 * @param rewardName Name of the reward that has to be fetched
 * @return Returns the reward based on the rewardName
 */
-(NSString*)getRewardByName:(NSString*)rewardName;

@end
