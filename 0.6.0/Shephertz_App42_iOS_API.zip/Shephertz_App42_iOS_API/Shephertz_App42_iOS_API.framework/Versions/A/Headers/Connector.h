//
//  Connector.h
//  App42_iOS_SERVICE_API
//
//  Created by Shephertz Technology on 07/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface Connector : NSObject<NSURLConnectionDelegate>{
    
    NSMutableURLRequest *mutableUrlRequest;
    
    NSMutableDictionary *mutableDictionary;
    
}

-(NSString*)executeGet:(NSString*)signature:(NSString*)url:(NSMutableDictionary*)dict;

-(NSString*)executePost:(NSString*)signature:(NSString*)url:(NSMutableDictionary*)dict:(NSString *)bodyPayload;

-(NSString*)executePut:(NSString*)signature:(NSString*)url:(NSMutableDictionary*)dict:(NSString *)bodyPayload;

-(NSString*)executeDelete:(NSString*)signature:(NSString*)url:(NSMutableDictionary*)dict;

@end
