//
//  Log.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 13/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Centralize logging for your App. This service allows different levels e.g. info,
 * debug, fatal, error etc. to log a message and query the messages based on 
 * different parameters.
 * You can fetch logs based on module, level, message, date range etc.
 * 
 */
@interface Log : NSObject{
   
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;



/**
 * Logs the info message
 * @param msg Message to be logged
 * @param module Module name for which the message is getting logged
 * @return the logged message
 */
-(NSString*)info:(NSString *)msg module:(NSString*)module;
/**
 * Logs the debug message
 * @param msg Message to be logged
 * @param module Module name for which the message is getting logged
 * @return the logged message
 */
-(NSString*)debug:(NSString *)msg module:(NSString*)module;
/**
 * Logs the fatal message
 * @param msg Message to be logged
 * @param module Module name for which the message is getting logged
 * @return the logged message
 */
-(NSString*)fatal:(NSString *)msg module:(NSString*)module;
/**
 * Logs the error message
 * @param msg Message to be logged
 * @param module Module name for which the message is getting logged
 * @return the logged message
 */
-(NSString*)error:(NSString *)msg module:(NSString*)module;
/**
 * Fetch the log messages based on the Module
 * @param moduleName Module name for which the messages has to be fetuched
 * @return Fetched messages
 */
-(NSString*)fetchLogsByModule:(NSString*)moduleName;
/**
 * Fetch log messages based on the Module and Message Text
 * @param moduleName Module name for which the messages has to be fetched
 * @param text The log message on which logs have to be searched
 * @return Fetched messages
 */
-(NSString*)fetchLogsByModuleAndText:(NSString*)moduleName text:(NSString*)text;
/**
 * Fetch the log messages based on the Level
 * @param level The level on which logs have to be searched
 * @return Fetched messages
 */
-(NSString*)fetchLogsByLevel:(NSString*)level;
/**
 * Fetch log messages based on Date range
 * @param startDate Start date from which the log messages have to be fetched
 * @param endDate End date upto which the log messages have to be fetched
 * @return Fetched messages
 */
-(NSString*)fetchLogByDateRange:(NSDate*)startDate endDate:(NSDate*)endDate;
/**
 * Fetch log messages based on Info Level
 * @return Fetched Info messages
 */
-(NSString*)fetchLogsByInfo;
/**
 * Fetch log messages based on Debug Level
 * @return Fetched Debug messages
 */
-(NSString*)fetchLogsByDebug;
/**
 * Fetch log messages based on Error Level
 * @return Fetched Error messages
 */
-(NSString*)fetchLogsByError;
/**
 * Fetch log messages based on Fatal Level
 * @return Fetched Fatal messages
 */
-(NSString*)fetchLogsByFatal;


@end
