//
//  Upload.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 15/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Uploads file to the cloud. Allows access to the files through url.
 * Its especially usefull for Mobile/Device apps. It minimizes the App footprint
 * on the device.
 * 
 */


typedef enum fileType{
    Audio,Video,Image,Binary,Txt,Xml,Csv,Json,Other
}FileType;


@interface Upload : NSObject{
   
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 *  Uploads file on the cloud.
 *  @param name The name for the file which has to be saved. It is used to retrieve the file
 *  @param filePath The local path for the file
 *  @param uploadFileType The type of the file. File can be either Audio, Video, Image, Binary, Txt, xml, json, csv or other
 *  Use the defined constants for them Audio,Video,Image,Binary,Txt,Xml,Csv,Json or other.
 *  @param description Description of the file to be uploaded.              
 *  @return The name and url for the file which is uploaded
 */
-(NSString*)uploadFile:(NSString*)name filePath:(NSString*)filePath uploadFileType:(FileType)uploadFileType fileDescription:(NSString*)description;
/**
 *  Gets all the files for the App
 *  @return The name and url for all the file which are uploaded
 */
-(NSString*)getAllFiles;
/**
 *  Gets the file based on file name.
 *  @param name The name of the file which has to be retrieved
 *  @return The name and url for the file 
 */
-(NSString*)getFileByName:(NSString*)name;
/**
 *  Removes the file based on file name.
 *  @param name The name of the file which has to be removed
 *  @return The name and url which has been removed
 */
-(NSString*)removeFileByName:(NSString*)name;
/**
 *  Removes all the files for the App
 *  @return The names and urls which have been removed
 */
-(NSString*)removeAllFiles;
/**
 *  Get the files based on file type.
 *  @param uploadFileType Type of the file e.g. Upload.AUDIO, Upload.XML etc.
 *  @return The name and url for the file 
 */
-(NSString*)getFilesByType:(FileType)uploadFileType;


@end
