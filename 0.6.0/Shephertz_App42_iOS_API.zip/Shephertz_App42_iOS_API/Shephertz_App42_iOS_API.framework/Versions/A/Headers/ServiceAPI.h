//
//  ServiceAPI.h
//  App42_iOS_SERVICE_APIs
//
//  Created by Shephertz Technology on 17/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceAPI : NSObject{
    
   
    NSString *apiKey;
    
   
    NSString *secretKey; 
}
/*!
 *set the api key of application
 */
@property(nonatomic,retain)NSString *apiKey;
/*!
 *set the secret key of application
 */
@property(nonatomic,retain)NSString *secretKey;
/*!
 *@return Returns the instance of User API
 */
-(id)buildUser;
/*!
 *@return Returns the instance of EmailSender API
 */
-(id)buildEmailSender;
/*!
 *@return Returns the instance of Message API
 */
-(id)buildMessage;
/*!
 *@return Returns the instance of License API
 */
-(id)buildLicense;
/*!
 *@return Returns the instance of Bill API
 */
-(id)buildBill;
/*!
 *@return Returns the instance of Storage API
 */
-(id)buildStorage;
/*!
 *@return Returns the instance of Session API
 */
-(id)buildSessionManager;
/*!
 *@return Returns the instance of Photo API
 */
-(id)buildPhoto;
/*!
 *@return Returns the instance of User API
 */
-(id)buildQueue;
/*!
 *@return Returns the instance of Usage API
 */
-(id)buildUsage;
/*!
 *@return Returns the instance of Recommender API
 */
-(id)buildRecommender;
/*!
 *@return Returns the instance of Upload API
 */
-(id)buildUpload;
/*!
 *@return Returns the instance of Catalogue API
 */
-(id)buildCatalogue;
/*!
 *@return Returns the instance of Cart API
 */
-(id)buildCart;
/*!
 *@return Returns the instance of Album API
 */
-(id)buildAlbum;
/*!
 *@return Returns the instance of Log API
 */
-(id)buildLog;
/*!
 *@return Returns the instance of Review API
 */
-(id)buildReview;
/*!
 *@return Returns the instance of Geo API
 */
-(id)buildGeo;
/*!
 *@return Returns the instance of Game API
 */
-(id)buildGame;
/*!
 *@return Returns the instance of Reward API
 */
-(id)buildReward;
/*!
 *@return Returns the instance of RewardPoint API
 */
-(id)buildRewardPoint;
/*!
 *@return Returns the instance of Score API
 */
-(id)buildScore;
/*!
 *@return Returns the instance of ScoreBoard API
 */
-(id)buildScoreBoard;
/*!
 *@return Returns the instance of Image Processor API
 */
-(id)buildImageProcessor;

@end
