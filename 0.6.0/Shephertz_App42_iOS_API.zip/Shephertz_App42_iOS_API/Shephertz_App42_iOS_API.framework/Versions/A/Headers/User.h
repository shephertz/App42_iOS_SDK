//
//  User.h
//  App42_iOS_SERVICE_API
//
//  Created by Shephertz Technology on 07/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ProfileData.h"
/**
 * Creates User for the App. App42 Cloud API's provides a complete User Management for any
 * Mobile or Web App. It supports User registration, retrieval, state management e.g. lock, delete
 * and Authentication.
 * 
 * Along with User management the platform provides API's for persistent SessionManagement
 * @see SessionManager
 */


@interface User : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property(nonatomic,retain)NSString *apiKey;
@property(nonatomic,retain)NSString *secretKey;
/**
 *  Create User for the App
 *  @param uName UserName which should be unique for the App
 *  @param pwd Password for the User
 *  @param emailAddress Email address of the user
 *  @return The created User.
 */
-(NSString*)createUser:(NSString*)uName password:(NSString*)pwd emailAddress:(NSString*)emailAddress;
/**
 *  Gets user details based on userName
 *  @param userName UserName which should be unique for the App
 *  @return Returns User Information
 */
-(NSString*)getUser:(NSString*)userName;
/**
 *  Updates the User based on userName. Note: Only email can be updated. Username cannot be updated.
 *  @param uName UserName which should be unique for the App
 *  @param emailAddress Email address of the user
 *  @returns Upadated User information
 */
-(NSString*)updateUser:(NSString*)uName emailAddress:(NSString*)emailAddress;
/**
 *  Deletes a particular user based on userName.
 *  @param userName UserName which should be unique for the App
 *  @returns Deleted User information
 */
-(NSString*)deleteUser:(NSString*)userName;
/**
 *  Creates or Updates User Profile. Note: First time the Profile for the user is created.
 *  In future calls user information will be updated
 *  @param uName UserName which should be unique for the App
 *  @param profile The Profile Data object which has the profile information
 *  @returns Upadated Profile information
 *  @see ProfileData
 */
-(NSString*)createOrUpdateProfile:(NSString *)uName profile:(ProfileData*)profile;
/**
 *  Authenticate user based on userName and password
 *  @param uName UserName which should be unique for the App
 *  @param password Password for the User
 *  @returns Whether the user is authenticated or not.
 */
-(NSString*)authenticateUser:(NSString*)uName password:(NSString*)password;
/**
 *  Locks the user based on the userName. Apps can use these feature to lock a user because of reasons specific to their
 *  usercase e.g. If payment not received and the App wants the user to be inactive
 *  @param uName UserName which should be unique for the App 
 *  @returns Returns the locked userName
 */
-(NSString*)lockUser:(NSString*)uName;
/**
 *  Unlock the user based on the userName. Apps can use these feature to unlock a user because of reasons specific to their
 *  usercase e.g. If payment received and the App wants to the user to be active.
 *  @param uName UserName which should be unique for the App
 *  @returns Returns the unlocked userName
 */
-(NSString*)unlockUser:(NSString*)uName;
/**
 *  Change the password for user based on the userName.
 *  @param uName UserName which should be unique for the App
 *  @param oldPwd Old Password for the user for authentication
 *  @param newPwd New Password for the user to change
 *  @returns Returns the changed password for the  user
 */
-(NSString*)changeUserPassword:(NSString*)uName oldPassword:(NSString*)oldPwd newPassword:(NSString*)newPwd;
@end
