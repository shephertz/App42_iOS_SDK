//
//  Recommender.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 13/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Recommendation engine which provides recommendation based on customer id, item id and the preference
 * of the customer for a particular Item.
 * Recommendations can be fetched based on User Similarity which finds similarity based on Users
 * and Item Similarity which finds similarity based on Items.
 * The Recommendation Engine currently supports two types of Similarity Algorithms i.e. EuclideanDistanceSimilarity
 * and PearsonCorrelationSimilarity. By default when similarity is not specified PearsonCorrelationSimilarity is used e.g.
 * in the method itemBased(String preferenceFileName, long userId, int howMany), it uses PearsonCorrelationSimilarity.
 * In the method itemBasedBySimilarity(String similarity, String preferenceFileName, long userId, int howMany) one can
 * specify which similarity algorithm has to be used e.g. Recommender.EUCLIDEAN_DISTANCE or Recommender.PEARSON_CORRELATION.
 * 
 * Preference file can be loaded using the method loadPreferenceFile(String fileName, String preferenceFilePath, String description)
 * in csv format. This preference file has to be uploaded once which can be a batch process
 * The csv format for the file is given below.
 *  customerId, itemId, preference
 *  e.g.
 *  1,101,5.0
 *  1,102,3.0
 *  1,103,2.5
 *
 *  2,101,2.0
 *  2,102,2.5
 *  2,103,5.0
 *  2,104,2.0
 *
 *  3,101,2.5
 *  3,104,4.0
 *  3,105,4.5
 *  3,107,5.0
 *
 *  4,101,5.0
 *  4,103,3.0
 *  4,104,4.5
 *  4,106,4.0
 *
 *  5,101,4.0
 *  5,102,3.0
 *  5,103,2.0
 *  5,104,4.0
 *  5,105,3.5
 *  5,106,4.0
 * The customer Id and item id can be any alphanumeric character(s) and preference values can be in any range.
 *     
 * If app developers have used the Review Service. The Recommendation Engine can be used in conjunction with Review. 
 * In this case a CSV preference file need not be uploaded. The customerId, itemId and preference will be taken from
 * Review where customerId is mapped with userName, itemId is mapped with itemId and preference with rating.
 * The methods for recommendations based on Reviews are part of the Review service
 * 
 * 
 * @see Review
 * 
 */

//extern NSString *const EUCLIDEAN_DISTANCE;
//extern NSString *const PEARSON_CORRELATION;


typedef enum Similarity{
    EUCLIDEAN_DISTANCE,PEARSON_CORRELATION
}similarityType;
 
 

@interface Recommender : NSObject{
   
    NSString *apiKey;
    NSString *secretKey;
    
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;

/**
 * Uploads preference file on the cloud. The preference file should be in CSV format.
 * This preference file has to be uploaded once which can be a batch process.
 * New versions of preference file either can be uploaded in a different name or the older one
 * has to be removed and the uploaded in the same name.
 * The csv format for the file is given below.
 *  customerId, itemId, preference
 *  e.g.
 *  1,101,5.0
 *  1,102,3.0
 *  1,103,2.5
 *
 *  2,101,2.0
 *  2,102,2.5
 *  2,103,5.0
 *  2,104,2.0
 *
 *  3,101,2.5
 *  3,104,4.0
 *  3,105,4.5
 *  3,107,5.0
 *
 *  4,101,5.0
 *  4,103,3.0
 *  4,104,4.5
 *  4,106,4.0
 *
 *  5,101,4.0
 *  5,102,3.0
 *  5,103,2.0
 *  5,104,4.0
 *  5,105,3.5
 *  5,106,4.0
 * The customer Id and item id can be any alphanumeric character(s) and preference values can be in any range.
 * If the recommendations have to be done based on Reviews then this file need not be uploaded.
 *
 * @param fileName Name of the Preference File based on which recommendations have to be found
 * @param preferenceFilePath Path of the preference file to be loaded
 * @param description Description of the preference file to be loaded
 * @return Returns the uploaded preference file details.
 * 
 */

-(NSString*)loadPreferenceFile:(NSString*)fileName preferenceFilePath:(NSString*)preferenceFilePath description:(NSString*)description;
/**
 * User based recommendations based on Neighborhood. Recommendations are found based on similar users in the Neighborhood
 * of the given user. The size of the neighborhood can be found.
 * @param preferenceFileName Name of the Preference File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param size Size of the Neighborhood
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)userBasedNeighborhood:(NSString*)preferenceFileName userId:(long)userId size:(int)size howMany:(int)howMany;
/**
 * User based neighborhood recommendations based on Threshold. Recommendations are found based on Threshold
 * where threshold represents similarity threshold where user are at least that similar.
 * Threshold values can vary from -1 to 1
 * @param preferenceFileName Name of the Preference File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param threshold Threshold size. Values can vary from -1 to 1
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)userBasedThreshold:(NSString*)preferenceFileName userId:(long)userId threshold:(double)threshold howMany:(int)howMany;
/**
 * User based recommendations based on Neighborhood and Similarity. Recommendations and found based on the similar users in the Neighborhood with 
 * the specified Similarity Algorithm. Algorithm can be specified using the constants EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param recommenderSimilarity Similarity algorithm e.g. Use the constants defined for Similarity algorithm i.e. EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param preferenceFileName Name of the Preference File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param size Size of the Neighborhood
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)userBasedNeighborhoodBySimilarity:(similarityType)recommenderSimilarity preferenceFileName:(NSString*)preferenceFileName userId:(long)userId size:(int)size howMany:(int)howMany;
/**
 * User based neighborhood recommendations based on Threshold. Recommendations are found based on Threshold
 * where threshold represents similarity threshold where user are at least that similar.
 * Threshold values can vary from -1 to 1
 * @param recommenderSimilarity Similarity algorithm e.g.Use the constants defined for Similarity algorithm i.e. EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param preferenceFileName Name of the Preference File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param threshold Threshold size. Values can vary from -1 to 1
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)userBasedThresholdBySimilarity:(similarityType)recommenderSimilarity preferenceFileName:(NSString*)preferenceFileName userId:(long)userId threshold:(double)threshold howMany:(int)howMany;
/**
 * Item based recommendations. Recommendations and found based item similarity
 * of the given user. The size of the neighborhood can be found.
 * @param preferenceFileName Name of the Preference File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)itemBased:(NSString*)preferenceFileName userId:(long)userId howMany:(int)howMany;

/**
 * Recommendations based on SlopeOne Algorithm
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)slopeOne:(NSString*)preferenceFileName userId:(long)userId howMany:(int)howMany;
/**
 * User based neighborood recommendations based on Threshold for all Users. Recommendations are found based on Threshold
 * where thereshold represents similarity threshold where user are atleast that similar.
 * Threshold values can vary from -1 to 1
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param threshold Threshold size. Values can vary from -1 to 1
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for all Users
 *
 */
-(NSString*)userBasedThresholdForAll:(NSString*)preferenceFileName threshold:(double)threshold howMany:(int)howMany;
/**
 * User based recommendations based on Neighborhood and Similarity for all Users. Recommendations and found based similar users in the Neighborhood with 
 * the specified Similarity Algorithm. Algorithim can be specified using the constants EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param recommenderSimilarity Similarity algorithm e.g. Use the constants defined for Similarity algorithm i.e. EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param size Size of the Neighborhood
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for all Users
 *
 */
-(NSString*)userBasedNeighborhoodBySimilarityForAll:(similarityType)recommenderSimilarity preferenceFileName:(NSString*)preferenceFileName size:(int)size howMany:(int)howMany;
/**
 * User based neighborood recommendations based on Threshold for All. Recommendations are found based on Threshold
 * where thereshold represents similarity threshold where user are atleast that similar.
 * Threshold values can vary from -1 to 1
 * @param recommenderSimilarity Similarity algorithm e.g. Use the constants defined for Similarity algorithm i.e. EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param threshold Threshold size. Values can vary from -1 to 1
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for All
 *
 */
-(NSString*)userBasedThresholdBySimilarityForAll:(similarityType)recommenderSimilarity preferenceFileName:(NSString*)preferenceFileName threshold:(double)threshold howMany:(int)howMany;
/**
 * Item based recommendations for all Users. Recommendations and found based item similarity
 * of the given user. The size of the neighborhood can be found.
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for all Users
 *
 */
-(NSString*)itemBasedForAll:(NSString*)preferenceFileName howMany:(int)howMany;
/**
 * Item based recommendations for all Users. Recommendations and found based one item similarity. Similarity algorithm can be specified.
 * of the given user. The size of the neighborhood can be found.
 * @param recommenderSimilarity Similarity algorithm e.g. Use the constants defined for Similarity algorithm i.e. EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for all Users
 *
 */
-(NSString*)itemBasedBySimilarityForAll:(similarityType)recommenderSimilarity preferenceFileName:(NSString*)preferenceFileName howMany:(int)howMany;
/**
 * Recommendations based on SlopeOne Algorithm for all Users
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for all Users
 *
 */
-(NSString*)slopeOneForAll:(NSString*)preferenceFileName howMany:(int)howMany;
/**
 * Item based recommendations. Recommendations and found based one item similarity. Similarity algorithm can be specified.
 * of the given user. The size of the neighborhood can be found.
 * @param recommenderSimilarity Similarity algorithm e.g. Use the constants defined for Similarity algorithm i.e. EUCLIDEAN_DISTANCE and PEARSON_CORRELATION
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param userId The user Id for whom recommendations have to be found
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations
 *
 */
-(NSString*)itemBasedBySimilarity:(similarityType)recommenderSimilarity preferenceFileName:(NSString*)preferenceFileName userId:(long)userId howMany:(int)howMany;
/**
 * User based recommendations based on Neighborhood for All Users. Recommendations and found based similar users in the Neighborhood
 * of the given user. The size of the neighborhood can be found.
 * @param preferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @param size Size of the Neighborhood
 * @param howMany Specifies that how many recommendations have to be found
 * @returns Recommendations for All users
 *
 */
-(NSString*)userBasedNeighborhoodForAll:(NSString*)preferenceFileName size:(int)size howMany:(int)howMany;
/**
 * Delete existing preference file.
 * @param peferenceFileName Name of the Prefeence File based on which recommendations have to be found
 * @returns File name which has been removed
 */
-(NSString*)deletePreferenceFile:(NSString*)peferenceFileName;

@end
