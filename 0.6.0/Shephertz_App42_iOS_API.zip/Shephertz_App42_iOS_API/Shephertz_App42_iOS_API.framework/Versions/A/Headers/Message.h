//
//  Message.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 11/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Service for sending, pulling and removing Message from a particular queue.
 * Asynchronous messages can be sent to a queue which can be pulled using various receive messages.
 * 
 */
@interface Message : NSObject{
    

    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 *  Send message on the queue with an expiry. The message will expire if it is not pulled/dequeued before the expiry
 *  @param queueName The name of the queue to which the message has to be sent
 *  @param msg Message that has to be sent
 *  @param exp Message expiry time
 *  @return The message which has been sent with its message id and correlation id
 */
-(NSString*)sendMessage:(NSString*)queueName message:(NSString*)msg expiryTime:(long)exp;
/**
 *  Pulls all the message from the queue
 *  @param queueName The name of the queue from which messages have to be pulled
 *  @param receiveTimeOut Receive time out
 *  @return All the messages which have been pulled
 */
-(NSString*)receiveMessage:(NSString*)queueName receiveTimeOut:(long)receiveTimeOut;
/**
 *  Pull message based on the correlation id
 *  @param queueName The name of the queue from which the message has to be pulled
 *  @param receiveTimeOut Receive time out
 *  @param correlationId Correlation Id for which message has to be pulled
 *  @return The message which has pulled based on the correlation id
 */
-(NSString*)receiveMessageByCorrelationId:(NSString*)queueName receiveTimeOut:(long)receiveTimeOut correlationId:(NSString*)correlationId;
/**
 *  Remove message from the queue based on the message id. Note: Once the message is removed it cannot be pulled
 *  @param queueName The name of the queue from which the message has to be removed
 *  @param messageId The message id of the message which has to be removed.
 *  @return The message which has been removed
 */
-(NSString*)removeMessage:(NSString*)queueName messageId:(NSString*)messageId;
@end
