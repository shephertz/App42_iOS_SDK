//
//  Photo.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 13/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Adds Photo to the created Album on the Cloud
 * All photos for a given Album can be managed through this service. Photos can be uploaded
 * to the cloud. Uploaded photos are accessible through the generated URL.
 * The service also creates a thumbnail for the Photo which has been uploaded.
 * 
 * @see Album
 */
@interface Photo : NSObject{
   
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;

/**
 * Adds Photo for a particular user and album. The Photo is uploaded on the cloud
 * @param userName Name of the User whose photo has to be added
 * @param albumName Name of the Album in which photo has to be added
 * @param photoName Name of the Photo that has to be added
 * @param photoDescription Description of the Photo that has to be added
 * @param path Path from where Photo has to be picked for addition
 * @return Returns the Photo which has been added
 */
-(NSString*)addPhoto:(NSString*)userName albumName:(NSString*)albumName photoName:(NSString*)photoName photoDescription:(NSString*)photoDescription path:(NSString*)path;
/**
 * Fetch all the Photos based on the userName
 * @param userName Name of the User whose photos have to be fetched
 * @return Returns all the Photos for the given userName
 */
-(NSString*)getPhotos:(NSString*)userName;
/**
 * Fetch all Photos based on the userName and album name
 * @param userName Name of the User whose photos have to be fetched
 * @param albumName Name of the Album from which photos have to be fetched
 * @return Returns all the Photos for the given userName and albumName
 */
-(NSString*)getPhotosByAlbumName:(NSString*)userName albumName:(NSString*)albumName;
/**
 * Fetch the particular photo based on the userName, album name and photo name
 * @param userName Name of the User whose photo has to be fetched
 * @param albumName Name of the Album from which photo has to be fetched
 * @param photoName Name of the Photo that has to be fetched
 * @return Returns the Photo for the given userName, albumName and photoName
 */
-(NSString*)getPhotosByAlbumAndPhotoName:(NSString*)userName albumName:(NSString*)albumName photoName:(NSString*)photoName;
/**
 * Removes the particular Photo from the specified Album for a particular user.
 * Note: The Photo is removed from the cloud and wont be accessible in future
 * @param userName Name of the User whose photo has to be removed
 * @param albumName Name of the Album in which photo has to be removed
 * @param photoName Name of the Photo that has to be removed
 * @return Returns the Photo which has been removed
 */
-(NSString*)removePhoto:(NSString*)userName albumName:(NSString*)albumName photoName:(NSString*)photoName;

@end
