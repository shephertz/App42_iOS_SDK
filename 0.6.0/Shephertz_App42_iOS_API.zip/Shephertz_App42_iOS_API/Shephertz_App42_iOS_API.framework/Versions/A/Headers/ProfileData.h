//
//  ProfileData.h
//  App42_iOS_SERVICE_APIs
//
//  Created by Shephertz Technology on 08/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

typedef enum sex{
    MALE,FEMALE
}SEX;

#import <Foundation/Foundation.h>
/**
 * Data object which captures User Profile Information.
 * Profile Data is used with User service
 * @see User
 * 
 */
@interface ProfileData : NSObject{
    
    NSString *firstName;
    NSString *lastName;
    SEX sex;
    NSString *mobile;
    NSString *line1;
    NSString *line2;
    NSString *city;
    NSString *state;
    NSString *country;
    NSString *pincode;
    NSString *homeLandLine;
    NSString *officeLandLine;
    NSDate *dateOfBirth;
    
}
/*!
 *set the first name in profile for user
 */
@property(nonatomic,retain) NSString *firstName;
/*!
 *set the last name in profile for user
 */
@property(nonatomic,retain) NSString *lastName;
/*!
 *set the sex in profile for user. We have defined Constants Value in enum SEX for them. Use the defined constants i.e. MALE and FEMALE. 
 */
@property(nonatomic) SEX sex;
/*!
 *set the mobile number in profile for user
 */
@property(nonatomic,retain) NSString *mobile;
/*!
 *set the line1 in profile for user
 */
@property(nonatomic,retain) NSString *line1;
/*!
 *set the line2 in profile for user
 */
@property(nonatomic,retain) NSString *line2;
/*!
 *set the city in profile for user
 */
@property(nonatomic,retain) NSString *city;
/*!
 *set the state in profile for user
 */
@property(nonatomic,retain) NSString *state;
/*!
 *set the country in profile for user
 */
@property(nonatomic,retain) NSString *country;
/*!
 *set the pincode in profile for user
 */
@property(nonatomic,retain) NSString *pincode;
/*!
 *set the homeLandline in profile for user
 */
@property(nonatomic,retain) NSString *homeLandLine;
/*!
 *set the officeLandline in profile for user
 */
@property(nonatomic,retain) NSString *officeLandLine;
/*!
 *set the date of birth in profile for user
 */
@property(nonatomic,retain) NSDate *dateOfBirth;


@end
