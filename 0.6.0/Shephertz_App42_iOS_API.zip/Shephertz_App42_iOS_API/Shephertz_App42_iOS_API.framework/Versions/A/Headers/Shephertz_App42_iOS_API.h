//
//  Shephertz_App42_iOS_API.h
//  Shephert_Test_App
//
//  Created by Shephertz Technology on 06/03/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Shephertz_App42_iOS_API/User.h>
#import <Shephertz_App42_iOS_API/ServiceAPI.h>
#import <Shephertz_App42_iOS_API/ProfileData.h>
#import <Shephertz_App42_iOS_API/Session.h>
#import <Shephertz_App42_iOS_API/EmailSender.h>
#import <Shephertz_App42_iOS_API/Message.h>
#import <Shephertz_App42_iOS_API/Queue.h>
#import <Shephertz_App42_iOS_API/Log.h>
#import <Shephertz_App42_iOS_API/Album.h>
#import <Shephertz_App42_iOS_API/Photo.h>
#import <Shephertz_App42_iOS_API/Recommender.h>
#import <Shephertz_App42_iOS_API/Bill.h>
#import <Shephertz_App42_iOS_API/License.h>
#import <Shephertz_App42_iOS_API/Cart.h>
#import <Shephertz_App42_iOS_API/Catalogue.h>
#import <Shephertz_App42_iOS_API/Usage.h>
#import <Shephertz_App42_iOS_API/Storage.h>
#import <Shephertz_App42_iOS_API/Upload.h>
#import <Shephertz_App42_iOS_API/Review.h>
#import <Shephertz_App42_iOS_API/ItemData.h>
#import <Shephertz_App42_iOS_API/Geo.h>
#import <Shephertz_App42_iOS_API/Game.h>
#import <Shephertz_App42_iOS_API/GeoPoint.h>
#import <Shephertz_App42_iOS_API/ImageProcessor.h>
#import <Shephertz_App42_iOS_API/Reward.h>
#import <Shephertz_App42_iOS_API/RewardPoint.h>
#import <Shephertz_App42_iOS_API/Score.h>
#import <Shephertz_App42_iOS_API/ScoreBoard.h>
#import <Shephertz_App42_iOS_API/App42Exception.h>
#import <Shephertz_App42_iOS_API/App42BadParameterException.h>
#import <Shephertz_App42_iOS_API/App42LimitException.h>
#import <Shephertz_App42_iOS_API/App42NotFoundException.h>
#import <Shephertz_App42_iOS_API/App42SecurityException.h>
