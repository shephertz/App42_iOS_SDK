//
//  ItemData.h
//  App42_iOS_SERVICE_APIs
//
//  Created by Shephertz Technology on 17/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 * Item information which has to be added in a Category for a particular Catalogue.
 * This is used along with a catalogue
 * 
 * @see Catalogue
 */
@interface ItemData : NSObject{
    NSString *itemId;
    NSString *name;
    NSString *image;
    NSString *description;
    double price;
}
/*!
 *set the price of item
 */
@property(nonatomic)double price;
/*!
 *set the Item Id of item
 */
@property(nonatomic,retain)NSString *itemId;
/*!
 *set the name of item
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set the image of item
 */
@property(nonatomic,retain)NSString *image;
/*!
 *set the description of item
 */
@property(nonatomic,retain)NSString *description;

@end
