//
//  Album.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 13/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Create Photo Gallery on the cloud. This service allows to manage i.e. create,
 * retrieve and remove albums on the cloud. Its useful for Mobile/Device App and Web App developer 
 * which want Photo Gallery functionality. It gives them a complete Photo Gallery out of the
 * box and reduces the footprint on the device. Developers can focus on how the Photo Gallery
 * will be rendered and this Cloud API will manage the Gallery on the cloud thereby reducing development
 * time. 
 * 
 * @see Photo
 */
@interface Album : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
    
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;

/**
 * Creates Album on the cloud
 * @param userName The user to which the album belongs
 * @param albumName Name of the album to be created on the cloud
 * @param albumDescription Description of the album to be created
 * @return Returns the album which has been created
 */
-(NSString*)createAlbum:(NSString*)userName albumName:(NSString*)albumName albumDescription:(NSString*)albumDescription;
/**
 * Fetches all the Albums based on the userName
 * @param userName The user for which the albums have to be fetched
 * @return Returns all the album for the given userName
 */
-(NSString*)getAlbums:(NSString*)userName;
/**
 * Fetch all Album based on the userName and albumName
 * @param userName The user for which the album has to be fetched
 * @param albumName Name of the album that has to be fetched
 * @return Returns the album for the given userName and albumName
 */
-(NSString*)getAlbumByName:(NSString*)userName albumName:(NSString*)albumName;
/**
 * Removes the album based on the userName and albumName. Note: All photos added to this Album will also be removed
 * @param userName The user for which the album has to be removed
 * @param albumName Name of the album that has to be removed
 * @return Returns the album which has been removed
 */
-(NSString*)removeAlbum:(NSString*)userName albumName:(NSString*)albumName;
@end
