//
//  SampleAppTests.h
//  SampleAppTests
//
//  Created by Shephertz Technology on 14/05/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SampleAppTests : SenTestCase

@end
