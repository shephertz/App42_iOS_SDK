//
//  TestClassAppDelegate.m
//  SampleApp
//
//  Created by Shephertz Technology on 14/05/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import "TestClassAppDelegate.h"
#import "Shephertz_App42_iOS_API/Shephertz_App42_iOS_API.h"
#import "Shephertz_App42_iOS_API/JSON.h"
@implementation TestClassAppDelegate

@synthesize window = _window;

- (void)dealloc
{
    [_window release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    serviceAPIObject = [[ServiceAPI alloc]init];//Allocate service api object
    serviceAPIObject.apiKey = @"8a3a75c806fa7dc5474f0639da4d5ccbfa7155d42f9a4a39ca4fbb313dcbec85";//assign api key
    serviceAPIObject.secretKey = @"efec19af24e07851e7d67efcac88b69f0c17f0d57fd5f91b7c344009ed7f8c07";//assign secret key
    
    UserService *userService = [serviceAPIObject buildUserService];

    
    @try {
        
        User *user = [userService createUser:@"User21" password:@"password21" emailAddress:@"user21@gmail.com"];
        NSString *userName = user.userName;
        NSString *email = user.email;    
        
        
    }
    @catch (App42BadParameterException *ex) {
        // Exception Caught
        // Check if User already Exist by checking app error code
        if (ex.appErrorCode == 2001) {
            // Do exception Handling for Already created User.
            NSLog(@"Bad Parameter Exception found. User With this name already Exists or there is some bad parameter");
        }
    } @catch (App42SecurityException *ex) {
        // Exception Caught
        // Check for authorization Error due to invalid Public/Private Key
        if (ex.appErrorCode == 1401) {
            // Do exception Handling here
            NSLog(@"Security Exception found");
        }
    }
    @catch (App42Exception *ex) {
        // Exception Caught due to other Validation
        NSLog(@"App42 Exception found");
    }

    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
