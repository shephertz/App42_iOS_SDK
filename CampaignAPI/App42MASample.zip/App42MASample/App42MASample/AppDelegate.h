//
//  AppDelegate.h
//  App42MASample
//
//  Created by Rajeev Ranjan on 11/12/15.
//  Copyright © 2015 Rajeev Ranjan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

