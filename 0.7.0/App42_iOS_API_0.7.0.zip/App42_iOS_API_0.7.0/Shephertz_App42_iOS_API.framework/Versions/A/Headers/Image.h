//
//  Image.h
//  App42_iOS_SERVICE_APIs
//
//  Created by Shephertz Technology on 21/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Image class contain the member variables and allowed to be set and get.
 * 
 */

@interface Image : App42Response{
    
    NSString *name;
    NSString *action;
    NSString *originalImage;
    NSString *convertedImage;
    double percentage;
    int width;
    int height;
    int x;
    int y;
   
}
/*!
 *set and get the name for Image Object
 */
@property(nonatomic,retain) NSString *name;
/*!
 *set and get the action for Image Object
 */
@property(nonatomic,retain) NSString *action;
/*!
 *set and get the originalImage for Image Object
 */
@property(nonatomic,retain) NSString *originalImage;
/*!
 *set and get the convertedImage for Image Object
 */
@property(nonatomic,retain) NSString *convertedImage;
/*!
 *set and get the percentage for Image Object
 */
@property(nonatomic,assign) double percentage;
/*!
 *set and get the width for Image Object
 */
@property(nonatomic,assign) int width;
/*!
 *set and get the height for Image Object
 */
@property(nonatomic,assign) int height;
/*!
 *set and get the x for Image Object
 */
@property(nonatomic,assign) int x;
/*!
 *set and get the y for Image Object
 */
@property(nonatomic,assign) int y;


@end
