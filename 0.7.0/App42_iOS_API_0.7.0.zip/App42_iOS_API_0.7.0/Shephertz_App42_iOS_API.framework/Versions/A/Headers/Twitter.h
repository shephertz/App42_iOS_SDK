//
//  Twitter.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 18/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Twitter class contain the member variables and allowed to be set and get.
 * 
 */
@interface Twitter : App42Response{
    
    NSString *consumerKey;
    NSString *consumerSecret;
    NSString *callbackUrl;
    NSString *requestTokenSecret;
    NSString *authorizationUrl;
    NSString *requestToken;
    NSString *userName;
    NSString *status;
    NSString *response;
    
}
/*!
 *set and get the consumer key for Twitter Object
 */
@property(nonatomic,retain) NSString *consumerKey;
/*!
 *set and get the consumer secret for Twitter Object
 */
@property(nonatomic,retain) NSString *consumerSecret;
/*!
 *set and get the callbackUrl for Twitter Object
 */
@property(nonatomic,retain) NSString *callbackUrl;
/*!
 *set and get the requestTokenSecret for Twitter Object
 */
@property(nonatomic,retain) NSString *requestTokenSecret;
/*!
 *set and get the authorizationUrl for Twitter Object
 */
@property(nonatomic,retain) NSString *authorizationUrl;
/*!
 *set and get the requestToken for Twitter Object
 */
@property(nonatomic,retain) NSString *requestToken;
/*!
 *set and get the userName for Twitter Object
 */
@property(nonatomic,retain) NSString *userName;
/*!
 *set and get the status for Twitter Object
 */
@property(nonatomic,retain) NSString *status;
/*!
 *set and get the response for Twitter Object
 */
@property(nonatomic,retain) NSString *response;

@end
