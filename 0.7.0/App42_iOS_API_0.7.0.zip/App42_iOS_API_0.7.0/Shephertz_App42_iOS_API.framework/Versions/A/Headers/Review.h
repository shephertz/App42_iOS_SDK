//
//  Review.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Review class contain the member variables and allowed to be set and get.
 * 
 */


@interface Review : App42Response{
    
    NSString *userId;
    NSString *itemId;
    NSString *status;
    NSString *reviewId;
    NSString *comment;
    double rating;
    NSDate *createdOn;
    
}
/*!
 *set and get the userId for Review Object
 */
@property(nonatomic,retain)NSString *userId;
/*!
 *set and get the itemId for Review Object
 */
@property(nonatomic,retain)NSString *itemId;
/*!
 *set and get the status for Review Object
 */
@property(nonatomic,retain)NSString *status;
/*!
 *set and get the reviewId for Review Object
 */
@property(nonatomic,retain)NSString *reviewId;
/*!
 *set and get the comment for Review Object
 */
@property(nonatomic,retain)NSString *comment;
/*!
 *set and get the rating for Review Object
 */
@property(nonatomic,assign)double rating;
/*!
 *set and get the createdOn for Review Object
 */
@property(nonatomic,retain)NSDate *createdOn;

@end
