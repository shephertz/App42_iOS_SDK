//
//  TwitterService.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 18/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "TwitterResponseBuilder.h"
#import "Twitter.h"
/**
 * Integrates with Twitter to update the User Status and also to get the
 * favourite tweets.
 * @see Twitter
 * @see App42Response
 */
@interface TwitterService : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 * Links the Twitter App credentials
 * (consumerKey/consumerSecret/callbackUrl) to the App that has to be
 * authorized.
 * 
 * @param consumerKey - Consumer Key of the Twitter App
 * @param consumerSecret - Consumer Secret of the Twitter App
 * @param callbackUrl - Callback URL of the Twitter App where to redirect
 *         after User authorize the App
 * @returns The Twitter object containing the App credentials
 *  
 */
-(Twitter *)linkAppCredentials:(NSString *)consumerKey consumerSecret:(NSString*)consumerSecret callbackUrl:(NSString*)callbackUrl;
/**
 * Returns the authorization URL on which User has to authorize the App to
 * interact with Twitter on his behalf.
 * 
 * @returns The Twitter object containing the authorization URL
 *  
 */
-(Twitter *)getAuthorizationURL;
/**
 * Links the User Twitter access credentials to the App User account.
 * 
 * @param userName - Name of the user whose Twitter account to be linked
 * @param requestToken - Request Token retrieved from Twitter after
 *         authorizing the App
 * @param requestTokenSecret - Request Token Secret retrieved from Twitter
 *         after authorizing the App
 * @returns the Twitter object
 *  
 */
-(Twitter *)linkUserTwitterAccount:(NSString *)userName requestToken:(NSString*)requestToken requestTokenSecret:(NSString*)requestTokenSecret;
/**
 * Updates the Twitter status of the specified user.
 * 
 * @param userName - Name of the user for whom the status needs to be
 *         updated
 * @param status - status that has to be updated
 * @returns The Twitter object
 *  @returns The Twitter object
 *  
 */
-(Twitter *)updateStatus:(NSString *)userName status:(NSString*)status;
/**
 * Returns the Favorite Tweets of the specified user.
 * 
 * @param userName - Name of the user for whom the information has to be
 *         retrieved
 * @returns The Twitter object containing the User's Favorite Tweets info
 *  
 */
-(Twitter *)getFavorites:(NSString *)userName;
@end
