//
//  ImageProcessorResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 13/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Image.h"
#import "App42ResponseBuilder.h"

@interface ImageProcessorResponseBuilder : App42ResponseBuilder

-(Image*)buildResponse:(NSString*)Json;

@end
