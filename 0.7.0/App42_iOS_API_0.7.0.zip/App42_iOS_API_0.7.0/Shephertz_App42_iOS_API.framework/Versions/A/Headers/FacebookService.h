//
//  FacebookService.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 18/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "FacebookResponseBuilder.h"
#import "Facebook.h"
/**
 * Integrates with Facebook to update the User Status and also to get the Facebook Info about that User.
 * @see Facebook
 * @see App42Response 
 */
@interface FacebookService : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 *  Links the Facebook App credentials (clientCode/clientSecret/callbackUrl) to the App that has to be authorized.
 *  @param clientCode - Client code of the Facebook App
 *  @param clientSecret - Client Secret of the Facebook App
 *  @param callbackUrl - Callback URL of the Facebook App where to redirect after User authorize the App
 *  @returns The Facebook object containing the App credentials
 *  
 */
-(Facebook *)linkAppCredentials:(NSString *)clientCode clientSecret:(NSString*)clientSecret callbackUrl:(NSString*)callbackUrl;
/**
 *  Returns the authorization URL on which User has to authorize the App to interact with Facebook on his behalf.
 *  @returns The Facebook object containing the authorization URL
 *  
 */
-(Facebook *)getAuthorizationURL;
/**
 *  Links the User Facebook access credentials to the App User account.
 *  @param userName - Name of the user whose Facebook account to be linked
 *  @param code - Code retrieved from Facebook after authorizing the App
 *  @returns The Facebook object
 *  
 */
-(Facebook *)linkUserFacebookAccount:(NSString *)userName code:(NSString*)code;
/**
 *  Updates the Facebook status of the specified user.
 *  @param userName - Name of the user for whom the status needs to be updated
 *  @param status - status that has to be updated
 *  @returns The Facebook object
 *  
 */
-(Facebook *)updateFacebookStatus:(NSString *)userName status:(NSString*)status;
/**
 *  Returns the Facebook info for the specified user.
 *  @param userName - Name of the user for whom the information has to be retrieved
 *  @returns The Facebook object containing the User's Facebook info
 *  
 */	
-(Facebook *)getFacebookInfo:(NSString *)userName;
@end
