//
//  GameResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42ResponseBuilder.h"
#import "Game.h"

@interface GameResponseBuilder : App42ResponseBuilder

-(Game*)buildResponse:(NSString*)Json;
-(NSArray*)buildArrayResponse:(NSString*)Json;

@end
