//
//  FacebookResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 18/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Facebook.h"
#import "App42ResponseBuilder.h"

@interface FacebookResponseBuilder : App42ResponseBuilder

-(Facebook*)buildResponse:(NSString*)Json;

@end
