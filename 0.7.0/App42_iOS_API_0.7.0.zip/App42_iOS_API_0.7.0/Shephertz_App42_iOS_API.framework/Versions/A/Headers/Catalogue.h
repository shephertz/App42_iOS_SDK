//
//  Catalogue.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 14/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
/**
 *Catalogue class contain the member variables and allowed to be set and get.
 * 
 */


@interface Catalogue : App42Response{
    
    NSString *name;
    NSString *description;
    NSMutableArray *categoryListArray;
}
/*!
 *set and get the name for Catalogue Object 
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set and get the description for Catalogue Object 
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the categoryListArray for Catalogue Object which contain the categoryData objects;
 */
@property(nonatomic,retain)NSMutableArray *categoryListArray;
@end

