//
//  TwitterResponseBuilder.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 18/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Twitter.h"
#import "App42ResponseBuilder.h"

@interface TwitterResponseBuilder : App42ResponseBuilder

-(Twitter*)buildResponse:(NSString*)Json;


@end
