//
//  Album.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Album class contain the member variables and allowed to be set and get.
 * 
 */


@interface Album :  App42Response{
    
    NSString *userName;
    NSString *name;
    NSString *description;
    NSMutableArray *photoList;
    
}
/*!
 *set and get the userName for Album Object 
 */
@property(nonatomic,retain)NSString *userName;
/*!
 *set and get the name for Album Object 
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set and get the description for Album Object 
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the photoList for Album Object Which contains the Photo Objects
 */
@property(nonatomic,retain)NSMutableArray *photoList;

@end


