//
//  ReviewService.h
//  App42_iOS_SERVICE_APIs
//
//  Created by shephertz technologies on 15/02/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReviewResponseBuilder.h"
@class Review;
/**
 * The service is a Review & Rating manager for any item. The item can be anything which has an id
 * e.g. App on a AppStore/Marketplace, items in a catalogue, articles, blogs etc.
 * It manages the comments and its associated rating. It also provides methods to fetch average, highest etc. Reviews.
 * Reviews can be also be muted or unmuted if it has any objectionable content.
 * 
 * @see Review
 * 
 */


@interface ReviewService : NSObject{
    
    NSString *apiKey;
    NSString *secretKey;
}
@property (nonatomic, retain) NSString *apiKey;
@property (nonatomic, retain) NSString *secretKey;
/**
 * Creates review for the specified item on the cloud
 * @param userId The user who has created the review
 * @param itemId The item for which the review has to be created
 * @param reviewComment The review comment
 * @param reviewRating Review rating in double
 * @return Review object containing the review which has been created
 */
-(Review*)createReview:(NSString*)userId itemID:(NSString*)itemId reviewComment:(NSString*)reviewComment reviewRating:(double)reviewRating;
/**
 * Fetches all reviews for the App
 * @return ArrayList of Review object containing all the reviews for the App
 */
-(NSArray*)getAllReviews;
/**
 * Fetches the average review for the specified itemId
 * @param itemId The item for which the average review has to be fetched
 * @return Review object containing the average review for a item
 */
-(Review*)getAverageReviewByItem:(NSString*)itemId;
/**
 * Fetches All Reviews based on the itemId
 * @param itemId The item for which reviews have to be fetched
 * @return ArrayList of Review object containing all the reviews for a item
 */
-(NSArray*)getReviewsByItem:(NSString*)itemId;
/**
 * Fetches the highest review for the specified itemId
 * @param itemId The item for which the highest review has to be fetched
 * @return Review object containing the highest review for a item
 */
-(Review*)getHighestReviewByItem:(NSString*)itemId;
/**
 * Fetches the lowest review for the specified itemId
 * @param itemId The item for which the lowest review has to be fetched
 * @return Review object containing the lowest review for a item
 */
-(Review*)getLowestReviewByItem:(NSString*)itemId;
/**
 *Mutes the specified review
 * @param reviewId The Id of the review which has to be muted
 * @return App42Response if muted successfully
 */
-(App42Response*)mute:(NSString*)reviewId;
/**
 * UnMutes the specified review
 * @param reviewId The Id of the review which has to be unmuted
 * @return App42Response if unmuted successfully
 */
-(App42Response*)unmute:(NSString*)reviewId;

@end
