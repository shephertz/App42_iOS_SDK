//
//  Geo.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Geo class contain the member variables and allowed to be set and get.
 * 
 */


@interface Geo : App42Response{
    
    NSString *storageName;
    NSString *sourceLat;
    NSString *sourceLng;   
    double distanceInKM;
    NSDate *createdOn;
    NSMutableArray *pointList;
    
}
/*!
 *set and get the storageName for Geo Object
 */
@property(nonatomic,retain)NSString *storageName;
/*!
 *set and get the sourceLat for Geo Object
 */
@property(nonatomic,retain)NSString *sourceLat;
/*!
 *set and get the sourceLng for Geo Object
 */
@property(nonatomic,retain)NSString *sourceLng;
/*!
 *set and get the distanceInKM for Geo Object
 */
@property(nonatomic,assign)double distanceInKM;
/*!
 *set and get the createdOn for Geo Object
 */
@property(nonatomic,retain)NSDate *createdOn;
/*!
 *set and get the pointList for Geo Object
 */
@property(nonatomic,retain)NSMutableArray *pointList;


@end
