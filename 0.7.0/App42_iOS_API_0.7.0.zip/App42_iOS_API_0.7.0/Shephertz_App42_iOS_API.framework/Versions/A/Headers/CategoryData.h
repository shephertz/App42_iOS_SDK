//
//  CategoryData.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 13/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
@class Catalogue;

/**
 *CategoryData class contain the member variables and allowed to be set and get.
 * 
 */

@interface CategoryData : App42Response{
    NSString *name;
    NSString *description;
    NSMutableArray *itemListArray;
    Catalogue *catalogueObject;
}
/*!
 *set and get the name for CategoryData Object 
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set and get the description for CategoryData Object 
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the itemListArray for CategoryData Object Which contains the categoryItem Objects
 */
@property(nonatomic,retain)NSMutableArray *itemListArray;
/*!
 *set and get the catalogueObject for CategoryData Object 
 */
@property(nonatomic,retain)Catalogue *catalogueObject;

- (id) init __attribute__((unavailable));

-(id)initWithCatalogue:(Catalogue*)catalogueObj;



@end
