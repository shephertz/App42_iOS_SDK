//
//  Photo.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
#import "Album.h"

/**
 *Photo class contain the member variables and allowed to be set and get .
 * 
 */

@interface Photo : App42Response{
    
    NSString *name;
    NSString *description;
    NSString *url;
    Album *albumObject;
        
}
/*!
 *set and get the name for Photo Object 
 */
@property(nonatomic,retain)NSString *name;
/*!
 *set and get the description for Photo Object 
 */
@property(nonatomic,retain)NSString *description;
/*!
 *set and get the url for Photo Object 
 */
@property(nonatomic,retain)NSString *url;
/*!
 *set and get the albumObject for Photo Object 
 */
@property(nonatomic,retain)Album *albumObject;

- (id) init __attribute__((unavailable));
-(id)initWithAlbum:(Album*)albumObj;

@end
