//
//  Facebook.h
//  PAE_iOS_SDK
//
//  Created by shephertz technologies on 18/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"

/**
 *Facebook class contain the member variables and allowed to be set and get.
 * 
 */

@interface Facebook : App42Response{
    
    NSString *clientCode;
    NSString *clientSecret;
    NSString *callbackUrl;
    NSString *authorizationUrl;
    NSString *userName;
    NSString *code;
    NSString *response;
    NSString *status;
    
}
/*!
 *set and get the clientCode for Twitter Object
 */
@property(nonatomic,retain) NSString *clientCode;
/*!
 *set and get the clientSecret for Twitter Object
 */
@property(nonatomic,retain) NSString *clientSecret;
/*!
 *set and get the callbackUrl for Twitter Object
 */
@property(nonatomic,retain) NSString *callbackUrl;
/*!
 *set and get the authorizationUrl for Twitter Object
 */
@property(nonatomic,retain) NSString *authorizationUrl;
/*!
 *set and get the userName for Twitter Object
 */
@property(nonatomic,retain) NSString *userName;
/*!
 *set and get the code for Twitter Object
 */
@property(nonatomic,retain) NSString *code;
/*!
 *set and get the response for Twitter Object
 */
@property(nonatomic,retain) NSString *response;
/*!
 *set and get the status for Twitter Object
 */
@property(nonatomic,retain) NSString *status;


@end
