//
//  LogMessage.h
//  PAE_iOS_SDK
//
//  Created by Shephertz Technology on 11/04/12.
//  Copyright (c) 2012 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "App42Response.h"
#import "Log.h"

/**
 *LogMessage class contain the member variables and allowed to be set and get.
 * 
 */

@interface LogMessage : App42Response{
    Log *logObject;
    
    NSString *message;
    NSString *type;
    NSDate *logTime;
    NSString *module;
    
}
/*!
 *set and get the logObject for LogMessage Object 
 */
@property(nonatomic,retain)Log *logObject;
/*!
 *set and get the message for LogMessage Object 
 */
@property(nonatomic,retain)NSString *message;
/*!
 *set and get the type for LogMessage Object 
 */
@property(nonatomic,retain)NSString *type;
/*!
 *set and get the logTime for LogMessage Object 
 */
@property(nonatomic,retain)NSDate *logTime;
/*!
 *set and get the module for LogMessage Object 
 */
@property(nonatomic,retain)NSString *module;
- (id) init __attribute__((unavailable));
-(id)initWithLog:(Log*)logObj;
@end